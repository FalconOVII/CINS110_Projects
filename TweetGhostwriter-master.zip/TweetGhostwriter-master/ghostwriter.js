function writeTweet()
{
  var randIndex;
  var sentance;
  var intro = ["There is no Dark Side", "There is no Light Side.", "There is only the Force",];
  var body = ["There is no good without evil.", "I will do what I must to keep the balance.", "Evil must not be allowed to flourish."];
  var end = ["I am a wielder of the flame, the protector of balance.", "I am the holder of the torch, lighting the way.", "I am the Gray Jedi.."];
  randIndex = randomUpTo(intro.length - 1);
  sentance = intro[randIndex];
  randIndex = randomUpTo(body.length - 1);
  sentance = sentance + " " + body[randIndex];
  randIndex = randomUpTo(end.length - 1);
  sentance = sentance + " " + end[randIndex];
  document.getElementById("tweet").innerHTML = sentance;
}

//Generates a random whole number between 0 and max (inclusive)
function randomUpTo(max)
{
  return Math.floor(Math.random() * (max+1));
}
