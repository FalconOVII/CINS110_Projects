function Start()
{
  window.location.href= "Question01.html";
}

// Question 1
function Answer1()
{
  var userInput = document.getElementById("answer").value;
  if(userInput == "0550")
  {
    setCookie("ans1", 1, 1);
    window.confirm("Your answer: " + userInput + "\nThat is Correct!");
  }
  else
  {
    setCookie("ans1", 0, 1);
    alert("Sorry that is the Wrong Answer");
  }
  window.location.href="Question02.html";
}

// Question 2
function Answer2()
{
  var userInput = document.getElementById("answer").value;
  if (userInput == "50")
  {
    setCookie("ans2", 1, 1);
    window.confirm("Your answer: " + userInput + "\nThat is Correct!");
  }
  else
  {
    setCookie("ans2", 0, 1);
    alert("Sorry that is the Wrong Answer");
  }
  window.location.href="Question03.html";
}

// Question 3
function Answer3()
{
  var userInput = document.getElementById("answer").value;
  if (userInput == "35")
  {
    setCookie("ans3", 1, 1);
    window.confirm("Your answer: " + userInput + "\nThat is Correct!");
  }
  else
  {
    setCookie("ans3", 0, 1);
    alert("Sorry that is the Wrong Answer");
  }
  window.location.href="Results.html";
}

function results()
{
  var ans1 = Number(getCookie("ans1"));
  var ans2 = Number(getCookie("ans2"));
  var ans3 = Number(getCookie("ans3"));
  var results = Number(ans1 + ans2 + ans3);
  percent = (results/3) * 100;
  console.log("results = " + results);
  document.getElementById("percent").innerHTML = "" + Math.round(percent) + "%";
}

// courtesy of w3schools, from: http://www.w3schools.com/js/js_cookies.asp
function setCookie(cname, cvalue, exdays)
{
  var d = new Date();
  d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
  var expires = "expires="+d.toUTCString();
  document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

// courtesy of w3schools, from: http://www.w3schools.com/js/js_cookies.asp
function getCookie(cname)
{
  var name = cname + "=";
  var ca = document.cookie.split(';');
  for(var i = 0; i < ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}
