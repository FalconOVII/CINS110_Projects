x10-Gatherinput
