# Frances-Allen
Author: Ivan Colio

Frances-Allen
- First Women to win the A.M. Turing Award, the highest honour in computer science.
- Recieved a bachelor's degree (1954) in mathematics from Albany State Teachers College.
- Master's degree (1957) in mathematics from the University of Michigan.
- Allen joined IBM's Thomas J. Watson Research Center, where she was first hired to teach staff scientists a new computer programming language named FORTRAN.
