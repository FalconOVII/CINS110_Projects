window.onload = main;

function main()
{
  console.log("Hello World!");
}

