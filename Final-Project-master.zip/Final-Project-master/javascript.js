function contactUs()
{
  alert("You must be kidding me, this is the Black Market Warehouse not Amazon. Go bug someone else.");
}

function customerService()
{
  alert("What? You got a complaint? Well too bad, what you see is what you get. No refunds.");
}

function aboutUs()
{
  alert("Didnt I already mention who we were in home page...oh is the page corrupted? hmmm.....my html skills must be lacking brb.");
}

function Info()
{
  window.location.href= "page5.html";
}

function Cart()
{
  window.location.href= "page6.html";
}

var totalcost = 0;
var myList = [];

function pushtoList(item)
{
  myList.push("item");
}

/*
function printList()
{
  var listLen = myList.length;
  for(int i = 0; i < listLen; i++)
  {
    text += "<li>" + myList[i] + "</li>";
  }
  document.write("----------------------------------------");
  document.write("$" + totalcost);
}
*/

function submit()
{
  window.location.href="page7.html";
}

function nuke()
{
  var userInput = document.getElementById("quantity").value;
  if(userInput == "one")
  {
    pushtoList("Nuclear Missle x1               $10000");
    totalcost = totalcost + 10000;
    setCookie("nuke1", 1, 1);
    window.location.href="page6.html";
  }
  else if(userInput == "two")
  {
    pushtoList("Nuclear Missle x2               $20000");
    totalcost = totalcost + 20000;
    setCookie("nuke2", 2, 1);
    window.location.href="page6.html";
  }
}

function gun()
{
  var userInput = document.getElementById("quantity").value;
  if(userInput == "one")
  {
    pushtoList("Heckler and Koch HK416 x1       $500");
    totalcost = totalcost + 500;
    setCookie("gun1", 1, 1);
    window.location.href="page6.html";
  }
  else if(userInput == "two")
  {
    pushtoList("Heckler and Koch HK416 x2       $1000");
    totalcost = totalcost + 1000;
    setCookie("gun2", 2, 1);
    window.location.href="page6.html";
  }
  else if(userInput == "three")
  {
    pushtoList("Heckler and Koch HK416 x3       $1500");
    totalcost = totalcost + 1500;
    setCookie("gun3", 3, 1);
    window.location.href="page6.html";
  }
  else if(userInput == "four");
  {
    pushtoList("Heckler and Koch HK416 x4       $2000");
    totalcost = totalcost + 2000;
    setCookie("gun4", 4, 1);
    window.location.href="page6.html";
  }
}

function morphine()
{
  var userInput = document.getElementById("quantity").value;
  if(userInput == "one")
  {
    pushtoList("Morphine x1                     $110");
    totalcost = totalcost + 110;
    setCookie("morph1", 1, 1);
    window.location.href="page6.html";
  }
  else if(userInput == "two")
  {
    pushtoList("Morphine x2                     $220");
    totalcost = totalcost + 220;
    setCookie("morph2", 2, 1);
    window.location.href="page6.html";
  }
  else if(userInput == "three")
  {
    pushtoList("Morphine x3                     $330");
    totalcost = totalcost + 330;
    setCookie("morph3", 3, 1);
    window.location.href="page6.html";
  }
  else if(userInput == "four");
  {
    pushtoList("Morphine x4                     $440");
    totalcost = totalcost + 440;
    setCookie("morph4", 4, 1);
    window.location.href="page6.html";
  }
}

function adderall()
{
  var userInput = document.getElementById("quantity").value;
  if(userInput == "one")
  {
    pushtoList("Adderall x1                     $110");
    totalcost = totalcost + 110;
    setCookie("drug1", 1, 1);
    window.location.href="page6.html";
  }
  else if(userInput == "two")
  {
    pushtoList("Adderall x2                     $220");
    totalcost = totalcost + 220;
    setCookie("drug2", 2, 1);
    window.location.href="page6.html";
  }
  else if(userInput == "three")
  {
    pushtoList("Adderall x3                     $330");
    totalcost = totalcost + 330;
    setCookie("drug3", 3, 1);
    window.location.href="page6.html";
  }
  else if(userInput == "four");
  {
    pushtoList("Adderall x4                     $440");
    totalcost = totalcost + 440;
    setCookie("drug4", 4, 1);
    window.location.href="page6.html";
  }
}

function chip()
{
  var userInput = document.getElementById("quantity").value;
  if(userInput == "one")
  {
    pushtoList("Nanodiamond Computer Chip x1    $20000");
    totalcost = totalcost + 20000;
    setCookie("chip1", 1, 1);
    window.location.href="page6.html";
  }
  else if(userInput == "two")
  {
    pushtoList("Nanodiamond Computer Chip x2    $40000");
    totalcost = totalcost + 40000;
    setCookie("chip2", 2, 1);
    window.location.href="page6.html";
  }
}

function lifeBook()
{
  var userInput = document.getElementById("quantity").value;
  if(userInput == "one")
  {
    pushtoList("The Meaning to Life Book x1     $5");
    totalcost = totalcost + 5;
    setCookie("book1", 1, 1);
    window.location.href="page6.html";
  }
}


// courtesy of w3schools, from: http://www.w3schools.com/js/js_cookies.asp
function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires="+ d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}
// courtesy of w3schools, from: http://www.w3schools.com/js/js_cookies.asp
function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i <ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}
